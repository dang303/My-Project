package com.example.convertingkmtomilesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
++++++++++00ditText MilesText = (EditText) findViewById(R.id.textMiles);
           EditText KMText = (EditText) findViewById(R.id.textKM);
           double vMiles = Double.valueOf(MilesText.getText().toString());
           double vKm = vMiles * 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                KMText.setText(formatVal.format(vKm));
            }

        });
// declare
        Button convertMiles = findViewById(R.id.convert2);
        // clickButton
        convertMiles.setOnClickListener (new View.OnClickListener(){

            public void onClick (View v){
                EditText MilesText = (EditText) findViewById(R.id.textMiles);
                EditText KMText = (EditText) findViewById(R.id.textKM);
                double vKm = Double.valueOf(KMText.getText().toString());
                double vMiles = vKm / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                MilesText.setText(formatVal.format(vMiles));
            }
        });

    }
}